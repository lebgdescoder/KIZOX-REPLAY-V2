package com.kizox.replay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

class ScreenRecordService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var isStarted = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            releaseRecorder()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startRecordingNotification()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (data != null && projection == null) startCapture(resultCode, data)
            }
            ACTION_STOP -> stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun startRecordingNotification() {
        val channelId = "kizox_recording"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "KIZOX Replay recording", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("KIZOX REPLAY")
                .setContentText("Enregistrement de l'écran actif")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("KIZOX REPLAY")
                .setContentText("Enregistrement de l'écran actif")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(projectionCallback, null)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)

            val width = (metrics.widthPixels / 2) * 2
            val height = (metrics.heightPixels / 2) * 2
            val densityDpi = metrics.densityDpi

            val folder = File(getExternalFilesDir(null), "Recordings").apply { mkdirs() }
            outputFile = File(folder, "KIZOX_${System.currentTimeMillis()}.mp4")

            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder?.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(width, height)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(6_000_000)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
            }

            val inputSurface = recorder?.surface ?: error("Surface vidéo indisponible")
            projection?.createVirtualDisplay(
                "KIZOX_REPLAY_CAPTURE",
                width,
                height,
                densityDpi,
                0,
                inputSurface,
                null,
                null
            )
            recorder?.start()
            isStarted = true
        } catch (error: Exception) {
            stopCapture()
        }
    }

    private fun stopCapture() {
        releaseRecorder()
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseRecorder() {
        try {
            if (isStarted) recorder?.stop()
        } catch (_: Exception) {
            outputFile?.delete()
        }
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        isStarted = false
    }

    override fun onDestroy() {
        releaseRecorder()
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        projection = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.kizox.replay.START"
        const val ACTION_STOP = "com.kizox.replay.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
    }
}
