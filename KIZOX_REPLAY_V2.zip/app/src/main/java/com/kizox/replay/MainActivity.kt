package com.kizox.replay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Background = Color(0xFF090D14)
private val SurfaceDark = Color(0xFF151D2A)
private val ElectricBlue = Color(0xFF28A5FF)
private val SecondaryText = Color(0xFF9BA9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KizoxReplayScreen() }
    }
}

@Composable
private fun KizoxReplayScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isRecording by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Prêt à enregistrer") }
    var showSettings by remember { mutableStateOf(false) }

    val screenCaptureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val permissionData = result.data
        if (result.resultCode == Activity.RESULT_OK && permissionData != null) {
            val serviceIntent = Intent(context, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenRecordService.EXTRA_DATA, permissionData)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            isRecording = true
            message = "Capture démarrée"
        } else {
            message = "Autorisation de capture refusée"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = ElectricBlue, background = Background, surface = SurfaceDark)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Background) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("KIZOX", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("REPLAY", color = ElectricBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        }
                        IconButton(onClick = { showSettings = !showSettings }) {
                            Icon(Icons.Default.Settings, contentDescription = "Paramètres", tint = Color.White)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(if (isRecording) "● REC" else "GAME CAPTURE",
                                color = if (isRecording) Color.Red else ElectricBlue,
                                fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Text(message, color = SecondaryText)
                            Spacer(Modifier.height(20.dp))
                            Button(
                                onClick = {
                                    if (!isRecording) {
                                        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
                                    } else {
                                        context.startService(Intent(context, ScreenRecordService::class.java).apply {
                                            action = ScreenRecordService.ACTION_STOP
                                        })
                                        isRecording = false
                                        message = "Enregistrement arrêté"
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(56.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color(0xFFB3261E) else ElectricBlue)
                            ) {
                                Icon(if (isRecording) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (isRecording) "ARRÊTER" else "DÉMARRER L'ENREGISTREMENT", fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("Android affiche une demande d'autorisation avant chaque session.", color = SecondaryText, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text("BIBLIOTHÈQUE", color = SecondaryText, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Folder, contentDescription = null, tint = ElectricBlue)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Enregistrements", fontWeight = FontWeight.Bold)
                                Text("Les fichiers seront sauvegardés dans le dossier privé de l'application dans cette version.", color = SecondaryText, fontSize = 11.sp)
                            }
                        }
                    }
                }
                if (showSettings) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("PARAMÈTRES", fontWeight = FontWeight.Bold)
                                Text("La configuration avancée (résolution, FPS, débit et audio) sera ajoutée après validation de la capture sur ta tablette.", color = SecondaryText)
                            }
                        }
                    }
                }
                item {
                    Text(
                        "Cette application enregistre une vidéo de l'écran. Elle ne récupère pas les données 3D du Replay Fortnite PC. La capture audio interne dépend des autorisations Android et du jeu.",
                        color = SecondaryText, fontSize = 11.sp
                    )
                }
            }
        }
    }
}
