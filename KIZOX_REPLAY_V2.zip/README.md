# KIZOX REPLAY V2 — Android starter

A minimal Kotlin/Jetpack Compose Android screen-recording prototype.

## Build requirements
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- Android SDK platform 35

## Build locally
Run `gradle assembleDebug` from this directory with Gradle 8.9 and JDK 17 installed.

## Important limitations
- This is a screen-video recorder prototype, **not** Fortnite's 3D Replay Mode.
- Android requires explicit user consent for every screen-capture session.
- This version captures video only; it does not yet capture internal game audio or microphone.
- It currently records at 30 FPS using the device display dimensions. 1080p/60 FPS needs device-specific encoder testing and configuration.
- Recordings are stored in the app-specific external files directory under `Recordings`; a media-library/export feature is not yet implemented.
- Long recordings consume storage and battery. Test short sessions first.

## Project package
`com.kizox.replay`
